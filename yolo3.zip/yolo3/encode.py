import math
from collections import OrderedDict
from torchvision import ops
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from config import anchors

# prediction


def encode(input:[]):
    a = input[0][0]
    '''
    把真实框的bx,by,bw,bh 转成相对信息 tx,ty,pw,ph
    '''

    return
