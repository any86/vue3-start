import math
from collections import OrderedDict
import torch
import torch.nn as nn
from config import anchors_13, anchors_26, anchors_52


def create_change_channel_conv2d(channel_in, channel_out, kernel_size):
    '''
    卷积的同时保证图片尺寸无变化
    '''
    pad = (kernel_size - 1) // 2 if kernel_size else 0
    return nn.Sequential(
        nn.Conv2d(channel_in, channel_out, kernel_size=kernel_size,
                  stride=1, padding=pad, bias=False),
        nn.BatchNorm2d(channel_out),
        nn.LeakyReLU(0.1),
    )


def create_conv2d_block_5l(channel_in, channel_out):
    '''
    执行5次卷积(1x1 -> 3x3 -> 1x1 -> 3x3 -> 1x1)
    对应图上的Conv2d Block 5L
    '''
    channel_out_2x = channel_out * 2
    return nn.Sequential(
        create_change_channel_conv2d(channel_in, channel_out, 1),
        create_change_channel_conv2d(channel_out, channel_out_2x, 3),
        create_change_channel_conv2d(channel_out_2x, channel_out, 1),
        create_change_channel_conv2d(channel_out, channel_out_2x, 3),
        create_change_channel_conv2d(channel_out_2x, channel_out, 1),
    )


def create_conv2d_upsampling2d(channel_in):
    half = channel_in // 2
    return nn.Sequential(
        create_change_channel_conv2d(channel_in, half, 1),
        nn.Upsample(scale_factor=2, mode='nearest')
    )


def create_yolo_head(channel_in, channel_out):
    '''
    最终数据,
    经过2个卷积(3 x 3 -> 1 x 1),
    生成置信度 + 位置 + 分类结构
    '''
    half = channel_in//2
    return nn.Sequential(
        create_change_channel_conv2d(channel_in, half, 3),
        # 因为后面没有bn层了,
        # 所以这里bias = True
        nn.Conv2d(half, channel_out,
                  kernel_size=1, stride=1, padding=0, bias=True)
    )


class Conv2dDownSampling(nn.Module):
    '''
    下采样
    通过卷积的步长为2进行下采样,
    传给残差块之前使用,
    用来减少参与计算的数据量
    '''

    def __init__(self, channel_in, channel_out):
        super(Conv2dDownSampling, self).__init__()
        self.__layer = nn.Sequential(
            nn.Conv2d(channel_in, channel_out, kernel_size=3,
                      stride=2, padding=1, bias=False),
            nn.BatchNorm2d(channel_out),
            nn.LeakyReLU(0.1)
        )

    def forward(self, x):
        return self.__layer(x)


class ResidualBlock(nn.Module):
    '''
    残差块
    '''

    def __init__(self, channel_in, channel_out):
        super(ResidualBlock, self).__init__()
        self._layers = nn.Sequential(
            nn.Conv2d(
                channel_in, channel_in, kernel_size=1, stride=1, padding=0, bias=False),
            nn.BatchNorm2d(channel_in),
            nn.LeakyReLU(0.1),
            nn.Conv2d(
                channel_in, channel_out, kernel_size=3, stride=1, padding=1, bias=False),
            nn.BatchNorm2d(channel_out),
            nn.LeakyReLU(0.1)
        )

    def forward(self, x):
        # return x + self._layers(x)
        residual = x
        out = self._layers(x)
        out += residual
        return out


# 52x52的特征图
layer_feature_52 = nn.Sequential(
    # 首先保持图片尺寸,
    # 同时扩张通道数
    # 416,416,3 -> 416,416,32
    nn.Conv2d(3, 32, kernel_size=3,
              stride=1, padding=1, bias=False),
    nn.BatchNorm2d(32),
    nn.LeakyReLU(0.1),

    # 416,416,32 -> 208,208,64
    Conv2dDownSampling(32, 64),
    ResidualBlock(64, 64),
    # 208,208,64 -> 104,104,128
    Conv2dDownSampling(64, 128),
    *[ResidualBlock(128, 128) for i in range(2)],
    # 104,104,128 -> 52,52,256
    Conv2dDownSampling(128, 256),
    *[ResidualBlock(256, 256) for i in range(8)],
)

# 26x26的特征图
layer_feature_26 = nn.Sequential(
    # 52,52,256 -> 26,26,512
    Conv2dDownSampling(256, 512),
    *[ResidualBlock(512, 512) for i in range(8)],
)

# 13x13的特征图
layer_feature_13 = nn.Sequential(
    # 512 x 26 x 26 -> 1024 x 13 13
    Conv2dDownSampling(512, 1024),
    *[ResidualBlock(1024, 1024) for i in range(4)],
)


class DarkNet(nn.Module):
    '''
    DarkNet
    组装所有层
    '''

    def __init__(self, classes_number):
        super(DarkNet, self).__init__()
        self.__classes_number = classes_number

    def forward(self, x):
        y0_52 = layer_feature_52(x)
        y0_26 = layer_feature_26(y0_52)
        y0_13 = layer_feature_13(y0_26)

        '''
        y0_开头的变量代表主干网络的最后3层的输出
        y1_开头的变量代表主干网络右侧的分支网络输出
        最终y = yolo_head(y1)
        '''
        # 1024 x 13 x 13 -> 512 x 13 x 13
        y1_13 = create_conv2d_block_5l(1024, 512)(y0_13)
        # 512 x 13 x 13 -> 256 x 26 x 26
        y1_26 = create_conv2d_upsampling2d(512)(y1_13)
        # 512 x 26 x 26 + 256 x 26 x 26 =-> 768 x 26 x 26
        y1_26 = torch.cat((y0_26, y1_26), 1)
        # 768 x 26 x 26 -> 256 x 26 x 26
        y1_26 = create_conv2d_block_5l(768, 256)(y1_26)

        # 256 x 26 x 26 -> 128 x 52 x 52
        y1_52 = create_conv2d_upsampling2d(256)(y1_26)

        # 256 x 52 x 52 + 128 x 52 x 52 -> 384 x 52 x 52
        y1_52 = torch.cat((y0_52, y1_52), 1)
        # # 384 x 26 x 26 -> 128 x 26 x 26
        y1_52 = create_conv2d_block_5l(384, 128)(y1_52)

        y_13 = create_yolo_head(512, len(anchors_13) *
                                (5 + self.__classes_number))(y1_13)
        y_26 = create_yolo_head(256, len(anchors_26) *
                                (5 + self.__classes_number))(y1_26)
        y_52 = create_yolo_head(128, len(anchors_52) *
                                (5 + self.__classes_number))(y1_52)

        # 对不同尺寸的特征图进行融合
        return y_13, y_26, y_52


if __name__ == "__main__":
    x = torch.randn((1, 3, 416, 416))
    images = torch.ones((10, 3, 416, 416))
    output = DarkNet(20)(images)
    print(output[0].shape, output[1].shape, output[2].shape)
