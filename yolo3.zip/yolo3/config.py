import torch

number_classes = 20
input_image_size = 416
grid_sizes = [13, 26, 52]
# 预选框
anchors_13 = [[116, 90], [156, 198], [373, 326]]
anchors_26 = [[30, 61], [62, 45], [59, 119]]
anchors_52 = [[10, 13], [16, 30], [33, 23]]
anchors = [anchors_13, anchors_26, anchors_52]

# 类别名称
classes_name = ['aeroplane',
                'bicycle',
                'bird',
                'boat',
                'bottle',
                'bus',
                'car',
                'cat',
                'chair',
                'cow',
                'diningtable',
                'dog',
                'horse',
                'motorbike',
                'person',
                'pottedplant',
                'sheep',
                'sofa',
                'train',
                'tvmonitor'
                ]


def get_scaled_anchors(anchors_index=None):
    '''
    获取特征图下的预选框尺寸
    '''
    if None == anchors_index:
        anchors_scaled = []
        for index in range(len(grid_sizes)):
            anchors_scaled.append(get_scaled_anchors(index))
        return torch.stack(anchors_scaled)
    else:
        grid_stride = input_image_size // grid_sizes[anchors_index]
        return torch.tensor([[anchor_width / grid_stride, anchor_height / grid_stride] for anchor_width, anchor_height in anchors[anchors_index]])


if __name__ == "__main__":
    a = get_scaled_anchors()
    exit(a)
