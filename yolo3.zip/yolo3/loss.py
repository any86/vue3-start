import torch
import torch.nn as nn


def yolo_loss(prediction, target):
    pass
