import math
from collections import OrderedDict
from torchvision import ops
from config import anchors, grid_sizes, input_image_size, classes_name
import matplotlib.pyplot as plt
import torch
import cv2
import torch.nn as nn
import numpy as np


def pad_image(image, target_size=416):
    '''
    以target_size为边生成矩形图片,
    然后缩放用户图片,
    让其最长边和矩形图边长相等,
    并居中填充到矩形图中
    '''
    if(isinstance(image, str)):
        image = cv2.imread(image)

    image = np.array(image)
    height, width, channel = image.shape
    scale = min(target_size / width, target_size / height)
    width_resized = int(width * scale)
    height_resized = int(height * scale)
    image_resized = cv2.resize(image, (width_resized, height_resized))
    image_target = np.full((target_size, target_size, 3),
                           128.0, dtype=np.uint8)
    x1 = (target_size - width_resized)//2
    x2 = x1 + width_resized
    y1 = (target_size - height_resized)//2
    y2 = y1 + height_resized
    image_target[y1: y2, x1:x2, :] = image_resized
    return image_target
    # cv2.imshow('', image_target)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()


class PadSquare(object):
    def __init__(self, size):
        self.size = size

    def __call__(self, image):
        '''
        以target_size为边生成矩形图片,
        然后缩放用户图片,
        让其最长边和矩形图边长相等,
        并居中填充到矩形图中
        '''
        return pad_image(image, self.size)


def voc_collate(batch):
    '''
    其实就把默认有的校验逻辑给跳过了
    '''
    # print(batch[0][0].shape)
    # exit()

    data = []
    # 按3种格子尺寸划分
    labels = []
    for item in batch:
        data.append(item[0])
        labels.append(transform_target(item[1]))
    return torch.stack(data), labels


def transform_label_name(label_name: str):
    '''
    转成独热码的形式
    '''
    length = len(classes_name)
    index = classes_name.index(label_name)
    # [0,0,0,0,1,0,0,0]
    return [(1 if index == i else 0) for i in range(length)]


def transform_target(target):
    annotation = target['annotation']
    # 原图尺寸
    size = annotation['size']
    # 选框信息
    boxes = annotation['object']
    # 转换后label
    group_labels = []
    

    # [3种尺寸,n个真实框]
    for grid_size in grid_sizes:
        scale = input_image_size / grid_size
        # 存储3种尺寸的真实框
        group_labels.append([])
        
        # 真实框
        for box in boxes:
            bndbox = box['bndbox']
            x = int(bndbox['xmin']) / scale
            y = int(bndbox['ymin']) / scale
            w = int(bndbox['xmax']) / scale - x
            h = int(bndbox['ymax']) / scale - y
            classes = transform_label_name(box['name'])
            # 1是confidence
            group_labels[len(group_labels)-1].append([x, y, w, h,1,*classes])
    return torch.tensor(group_labels)
    # print(yolo_labels[2])


# class Resize(object):
#     def __init__(self, size):
#         self.size = size

#     def __call__(self, data):
#         img, boxes = data
#         img = F.interpolate(img.unsqueeze(0), size=self.size,
#                             mode="nearest").squeeze(0)
#         return img, boxes


def draw_box(x, y, width, height, row, col):
    fig, ax = plt.subplots()
    ax.grid(c='#a1a3a6', linestyle='--', linewidth=0.5)
    ax.xaxis.set_ticks_position('top')
    ax.yaxis.set_ticks_position('left')
    rect = plt.Rectangle([x, y], width, height,
                         edgecolor='r', facecolor='none')
    ax.add_patch(rect)
    ax.set_xlim(0, row)
    ax.set_ylim(col, 0)
    plt.show()


# 构造batch_size * anchor_number * row_number * col_number
# 用1表示格子单位长度,
# 比如13 x 13格子数据如下:
# [
#   [0,1,2,3,...13],
#   [0,1,2,3,...13],
#   ...
#   [0,1,2,3,...13]
# ]
# 输出维度(batch_size , anchor_number , row_number , col_number)


def create_grid(batch_size, anchor_number, row_number, col_number):
    # 构造行
    out = torch.linspace(0, row_number-1, row_number)
    # 构造列
    out = out.repeat(col_number, 1)
    # 构造3组grid
    out = out.repeat(anchor_number, 1, 1)
    # 复制batch_size份
    return out.repeat(batch_size, 1, 1, 1)


'''
解析单个bounding box
注意!!! 
代码注释会以13 x 13的先验框为例
data是darknet输出的数据, 
注意这里接收的是3种尺寸中的某一尺寸先验框对应的数据
'''
# voc2005有4个类别
# 27 = 3 x [tx,tx,tw,th,confidence,classes(5)]


def decode_box(data, anchors, class_number=4, image_size=416):
    # 一个格子对应的锚框数量
    # yolov3默认值3
    # 表示一个格子对应3个预选锚框
    anchor_number = len(anchors)

    batch_size = data.size(0)
    # 格子行列数, 宽高一样,
    # 其实就是下采样后特征图的尺寸(像素)
    grid_row_number = data.size(2)
    # 其实行列值是一样的
    grid_col_number = data.size(3)

    # 格子步长,其实就是一个格子对应原图多少个像素
    grid_stride = image_size / grid_row_number

    # 5是固定值,
    # 表示tx,tx,tw,th,confidence
    # tx/ty表示当前格子对应的预选锚框需要偏移多少才是物体的中心
    # tw/th表示锚框需要缩放的比例
    # confidence是置信度, 表示为当前格子包含物体中心的可能性
    # 举例: [10, 3, 13, 13, 9]
    # 其中9 = 5个锚框信息 + 4个类别独热码
    prediction = data.view((
        batch_size,
        anchor_number,
        5 + class_number,
        grid_row_number,
        grid_col_number
    )).permute(0, 1, 3, 4, 2).contiguous()

    tx = prediction[..., 0]
    ty = prediction[..., 1]
    tw = prediction[..., 2]
    th = prediction[..., 3]
    confidence = prediction[..., 4]
    classes = prediction[..., 5:]

    '''
    生成格子坐标
    batch x 3 x 13 x 13
    目标框中心 = grid_x + tx
    也就是格子左上角x坐标 + x修正
    '''

    grid_x = create_grid(batch_size, anchor_number,
                         grid_row_number, grid_col_number)
    # 其实结果和grid_x一样
    grid_y = create_grid(batch_size, anchor_number,
                         grid_col_number, grid_row_number)

    '''
    生成先验框, 最后一维里面的数字是宽度或高度
    batch_size x 3 x 13 x 13(宽度或高度)
    '''
    anchors_scaled = [(anchor_width / grid_stride, anchor_height / grid_stride)
                      for anchor_width, anchor_height in anchors]

    anchor_w = torch.tensor(anchors_scaled).index_select(1, torch.tensor([0]))
    anchor_h = torch.tensor(anchors_scaled).index_select(1, torch.tensor([1]))
    grid_total = grid_row_number*grid_col_number
    anchor_w = anchor_w.repeat(
        batch_size, 1, grid_total).view([batch_size, 3, grid_row_number, grid_col_number])

    anchor_h = anchor_h.repeat(
        batch_size, 1, grid_total).view([batch_size, 3, grid_row_number, grid_col_number])
    # print(anchor_h.shape)
    # exit()
    # print(anchor_w[0,2],anchor_w[0,2].shape)

    # stride 格子步长,其实就是一个格子的边包含多少个像素
    # cx / cy 该点所在网格的左上角距离最左上角相差的格子数, 其实就是特征图上的每一像素距离
    # pw / ph 先验框映射到特征图中的宽和高
    # tx / ty 目标中心点相对于该点所在网格左上角的偏移量, 其实就是特征图上的像素偏移距离,
    # 因为格子尺寸为单位1, 为了加上偏移不超出格子, 所以用sigmoid归一化
    # tw / th 缩放尺寸
    # 最终得到的边框坐标值是bx,by,bw,bh.而网络学习目标是tx,ty,tw,th。
    # tx, ty, tw, th, confidence, classes

    '''
    变形
    batch x 3 x 13 x 13 x 9
    9 = bx,by,bw,bh,confidence, classes(4, voc2005有4个类别)
    '''
    pw = anchor_w
    ph = anchor_h
    bx = grid_x + torch.sigmoid(tx)
    by = grid_y + torch.sigmoid(ty)
    bw = pw * torch.exp(tw)
    bh = ph * torch.exp(th)
    confidence = torch.sigmoid(confidence)
    classes = torch.sigmoid(classes)

    # 最里面增加一个维度, 存储tx/classes等数据
    prediction_transform = torch.empty(
        [batch_size, anchor_number, grid_row_number, grid_col_number, 5+class_number])
    prediction_transform[..., 0] = bx
    prediction_transform[..., 1] = by
    prediction_transform[..., 2] = bw
    prediction_transform[..., 3] = bh
    prediction_transform[..., 4] = confidence
    prediction_transform[..., 5:] = classes
    # print(prediction_transform.shape)
    return prediction_transform


# x, y, w, h, *other = row[12].tolist()
# draw_box(x, y, w, h, len(row), len(row))

bboxes = torch.tensor([
    [10, 10, 90, 90, 0.81, 0.65, 0.7, 0.1],
    [10, 10, 60, 60, 0.67, 0.52, 0.7, 0.2],
    [20, 20, 30, 30, 0.28, 0.91, 0.7, 0.3]
])


def box_iou(box1, box2):
    '''
    输入的box是[x1,y1,x2,y2]
    '''
    # 计算2个框的面积
    [boxes1_area, boxes2_area] = [
        (box[..., 2] - box[..., 0]) * (box[..., 3] - box[..., 1]) for box in [box1, box2]]

    # 交集2个端点
    intersection_top_left = torch.maximum(box1[..., :2], box2[..., :2])
    intersection_bottom_right = torch.minimum(box1[..., 2:4], box2[..., 2:4])
    # 交集边长
    intersection_side_length = torch.maximum(
        intersection_bottom_right - intersection_top_left, torch.tensor(0))
    # 计算交集面积
    intersection_area = intersection_side_length[...,
                                                 0] * intersection_side_length[..., 1]
    # 并集面积
    union_area = boxes1_area + boxes2_area - intersection_area

    return intersection_area / union_area


def box_iou_only_wh(box1, box2):
    '''
    输入的box是[w,h],
    假设都是左上角对齐
    每个预选框的中心位置默认是相同的
    所以可以简单直接比较面积计算iou,
    '''
    _boxes = []
    for box in [box1, box2]:
        _box = torch.zeros_like(box)
        _boxes.append(torch.cat([_box, box], -1))

    return box_iou(*_boxes)


def box_iou_tlwh(box1, box2):
    '''
    输入的box是[left,top,width,height]
    '''
    _boxes = []
    for box in [box1, box2]:
        _box = torch.zeros_like(box)
        _box[..., 0:2] = box[..., 0:2]
        _box[..., 2:4] = box[..., 0:2] + box[..., 2:4]
        _boxes.append(_box)
    return _boxes

# def nms(bounding_boxes, iou_threshold=0.5):
#     boxes = torch.zeros(bounding_boxes.shape)
#     boxes[..., 0] = bounding_boxes[..., 0] - bounding_boxes[..., 2] / 2
#     boxes[..., 1] = bounding_boxes[..., 1] - bounding_boxes[..., 3] / 2
#     boxes[..., 2] = bounding_boxes[..., 0] + bounding_boxes[..., 2] / 2
#     boxes[..., 3] = bounding_boxes[..., 0] + bounding_boxes[..., 2] / 2

#     torch.max(bounding_boxes[..., 5:],)

#     return bounding_boxes[..., 5:]


# bboxes = torch.tensor([
#     [0, 0, 100, 100, 0.8, 0.61, 0.7, 0.1],
#     [10, 10, 100, 100, 0.82, 0.52, 0.7, 0.1],
#     [0, 0, 10, 10, 0.71, 0.93, 0.7, 0.1]
# ])

bboxes = torch.tensor([
    [0, 0, 100, 100, 0.8],
    [10, 10, 100, 100, 0.82],
    [0, 0, 10, 10, 0.71],
    [10, 20, 10, 10, 0.721],
    [10, 30, 10, 10, 0.711],
])

# a = ops.nms(bboxes[...,0:4],bboxes[...,4],0.5)
# a = box_iou(bboxes[2], bboxes)
# print(a)


def nms(boxes, scores, iou_threshold):
    keep = []
    # 分数从小到大排序后的索引队列
    indexs_sorted = scores.argsort()

    while(0 < indexs_sorted.numel()):
        max_score_index = indexs_sorted[-1]
        max_score_box = boxes[max_score_index]
        keep.append(max_score_index)

        # 就剩余一个框
        if indexs_sorted.size(0) == 1:
            break

        # 移除当前最大值的索引
        indexs_sorted = indexs_sorted[:-1]
        # 当前非最大值的索引队列
        no_max_boxes = boxes[indexs_sorted]
        ious = box_iou(max_score_box, no_max_boxes)
        # 过滤掉超过阈值的iou
        indexs_sorted = indexs_sorted[ious <= iou_threshold]

    # 变成1维
    keep = indexs_sorted.new(keep)
    return keep


# o = nms(bboxes[..., :4], bboxes[..., 4], 0.7)
# print(o)


def transform_truly(truly):
    '''
    把真实值转换到不同特征图尺寸下(比如13 x 13)
    loss函数中的计算都是针对不同特征图下的
    '''
    # shape_true = (number_batch, number_anchor,
    #               number_grid_size, number_grid_size)
    number_classes = len(classes_name)

    shape_true = (len(truly), 3, 13, 13)

    true_target = torch.empty((*shape_true, 4))

    # 置信度mask
    obj_mask = torch.zeros(shape_true)
    non_obj_mask = torch.ones(shape_true)

    classes = torch.zeros((*shape_true, number_classes))
    iou_mask = torch.zeros(shape_true)

    tx = torch.zeros(shape_true)
    ty = torch.zeros(shape_true)
    tw = torch.zeros(shape_true)
    th = torch.zeros(shape_true)

    true_target[..., 0] = tx
    true_target[..., 1] = ty
    true_target[..., 2] = tw
    true_target[..., 3] = th

    return true_target
    # return torch.cat(tx,ty,tw,th,classes,-1)
    # target_mask = torch.FloatTensor()
    # gxy
    # gwh
    # box_iou()


if __name__ == "__main__":
    a = transform_target()

    print(a[1, 2, 12, 12])
    print(a.shape)

    exit()
