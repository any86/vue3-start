from torchvision import datasets, transforms, utils
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import cv2
import numpy as np
from utils import PadSquare, voc_collate, box_iou, transform_label_name, box_iou_only_wh,transform_target
import pprint
from torchvision.datasets import VOCDetection
from darknet import DarkNet
from decode import decode
from config import get_scaled_anchors, number_classes

# a = transfrom_label_name('cow')
# exit(a)
# a = get_scaled_anchors()
# exit(a[0])

pprint = pprint.PrettyPrinter(indent=2).pprint
transform = transforms.Compose([PadSquare(416), transforms.ToTensor()])

dataset_train = VOCDetection('./datasets', year='2007', transform=transform,
                             image_set='trainval', download=False)
dataset_test = VOCDetection('./datasets', year='2007', transform=transform,
                            image_set='test', download=False)

loader_train = torch.utils.data.DataLoader(
    dataset_train, batch_size=2, collate_fn=voc_collate, shuffle=False, )

images, targets = next(iter(loader_train))


print(targets[0].shape)




exit()
# c = torch.tensor(targets[0])[...,2:4]
# anchors_scaled = get_scaled_anchors(0)
# b = torch.stack([box_iou_only_wh(anchor_scaled, c)
#                 for anchor_scaled in anchors_scaled])
# c = b.max(0)
# exit(c)
a = transform_target(targets)
print(a.shape)
exit()

prediction = DarkNet(number_classes)(images)
prediction, anchors_scaled_group = decode(prediction, number_classes)


number_batch = prediction[0].size(0)
number_anchor = prediction[0].size(1)
number_grid_size = prediction[0].size(2)






# pprint(anchors)
# pprint(targets[0]['annotation']['size'])
# pprint(targets[0]['annotation']['object'][1]['bndbox'])

# print(prediction[0].shape, prediction[1].shape, prediction[2].shape)
# print(prediction[0][1][2].shape)
# print(prediction[0][1][2][5][3])

# (s|m|l), batch, anchor, size,size, info
# print(prediction[0][1][2][3])

# print(prediction[0][1][2][3])
