import math
from collections import OrderedDict
from torchvision import ops
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from config import anchors


# 构造batch_size * anchor_number * row_number * col_number
# 用1表示格子单位长度,
# 比如13 x 13格子数据如下:
# [
#   [0,1,2,3,...13],
#   [0,1,2,3,...13],
#   ...
#   [0,1,2,3,...13]
# ]
# 输出维度(batch_size , anchor_number , row_number , col_number)


def create_grid(batch_size, anchor_number, row_number, col_number, rotation: bool = False):
    # 构造行
    out = torch.linspace(0, row_number-1, row_number)
    # 构造列
    out = out.repeat(col_number, 1)

    if rotation:
        out = out.t()

    # 构造3组grid
    out = out.repeat(anchor_number, 1, 1)
    # 复制batch_size份
    return out.repeat(batch_size, 1, 1, 1)


# voc2005有4个类别
# 27 = 3 x [tx,tx,tw,th,confidence,classes(4)]

def decode_box(darknet_output, anchors, class_number, image_size=416):
    '''
    解析单个bounding box
    darknet_output 是darknet返回的其中一个格子尺寸对应的数据, 
    比如: batch_size x 27 x 13 x 13

    注意!!! 
    代码注释会以13 x 13的先验框为例
    data是darknet输出的数据, 
    注意这里输出的是3种尺寸中的某一尺寸先验框对应的数据
    '''

    # 一个格子对应的锚框数量
    # yolov3默认值3
    # 表示一个格子对应3个预选锚框
    anchor_number = len(anchors)

    batch_size = darknet_output.size(0)
    # 格子行列数, 宽高一样,
    # 其实就是下采样后特征图的尺寸(像素)
    grid_row_number = darknet_output.size(2)
    # 其实行列值是一样的
    grid_col_number = darknet_output.size(3)

    # 格子步长,其实就是一个格子对应原图多少个像素
    grid_stride = image_size / grid_row_number

    # 5是固定值,
    # 表示tx,tx,tw,th,confidence
    # tx/ty表示当前格子对应的预选锚框需要偏移多少才是物体的中心
    # tw/th表示锚框需要缩放的比例
    # confidence是置信度, 表示为当前格子包含物体中心的可能性
    # 举例: [10, 3, 13, 13, 9]
    # 其中9 = 5个锚框信息 + 4个类别独热码
    prediction = darknet_output.view((
        batch_size,
        anchor_number,
        5 + class_number,
        grid_row_number,
        grid_col_number
    )).permute(0, 1, 3, 4, 2).contiguous()

    # darknet返回的是预测框中心(也是某个网格的左上角坐标)的偏移和高宽缩放信息
    # 后面要进行要变换到绝对位置和高宽
    tx = prediction[..., 0]
    ty = prediction[..., 1]
    tw = prediction[..., 2]
    th = prediction[..., 3]
    confidence = prediction[..., 4]
    classes = prediction[..., 5:]

    # 生成格子坐标
    # batch x 3 x 13 x 13
    # 目标框中心 = grid_x + tx
    # 也就是格子左上角x坐标 + x修正
    grid_x = create_grid(batch_size, anchor_number,
                         grid_row_number, grid_col_number)
    # 其实结果和grid_x一样
    grid_y = create_grid(batch_size, anchor_number,
                         grid_col_number, grid_row_number, True)

    # 生成先验框, 最后一维里面的数字是宽度或高度
    # batch_size x 3 x 13 x 13(宽度或高度)
    anchors_scaled = [(anchor_width / grid_stride, anchor_height / grid_stride)
                      for anchor_width, anchor_height in anchors]

    anchor_w = torch.tensor(anchors_scaled).index_select(1, torch.tensor([0]))
    anchor_h = torch.tensor(anchors_scaled).index_select(1, torch.tensor([1]))
    grid_total = grid_row_number*grid_col_number
    anchor_w = anchor_w.repeat(
        batch_size, 1, grid_total).view([batch_size, 3, grid_row_number, grid_col_number])

    anchor_h = anchor_h.repeat(
        batch_size, 1, grid_total).view([batch_size, 3, grid_row_number, grid_col_number])
    # print(anchor_h.shape)
    # exit()
    # print(anchor_w[0,2],anchor_w[0,2].shape)

    # stride 格子步长,其实就是一个格子的边包含多少个像素
    # cx / cy 该点所在网格的左上角距离最左上角相差的格子数, 其实就是特征图上的每一像素距离
    # pw / ph 先验框映射到特征图中的宽和高
    # tx / ty 目标中心点相对于该点所在网格左上角的偏移量, 其实就是特征图上的像素偏移距离,
    # 因为格子尺寸为单位1, 为了加上偏移不超出格子, 所以用sigmoid归一化
    # tw / th 缩放尺寸
    # 最终得到的边框坐标值是bx,by,bw,bh.而网络学习目标是tx,ty,tw,th。
    # tx, ty, tw, th, confidence, classes

    # 变形
    # batch x 3 x 13 x 13 x 9
    # 9 = bx,by,bw,bh,confidence, classes(4, voc2005有4个类别)
    pw = anchor_w
    ph = anchor_h
    bx = grid_x + torch.sigmoid(tx)
    by = grid_y + torch.sigmoid(ty)
    bw = pw * torch.exp(tw)
    bh = ph * torch.exp(th)
    confidence = torch.sigmoid(confidence)
    classes = torch.sigmoid(classes)
    # 最里面增加一个维度, 存储tx/classes等数据
    prediction_absolute = torch.empty(
        [batch_size, anchor_number, grid_row_number, grid_col_number, 5+class_number])
    prediction_absolute[..., 0] = bx
    prediction_absolute[..., 1] = by
    prediction_absolute[..., 2] = bw
    prediction_absolute[..., 3] = bh
    prediction_absolute[..., 4] = confidence
    prediction_absolute[..., 5:] = classes
    return prediction_absolute,anchors_scaled


def decode(darknet_output, classes_num):
    '''
    相对特征图(13x13等)的预测框信息
    '''
    # anchor_number / 3 = 5 + classes_num
    # classes_num = len(darknet_output[0][0])//3 - 5
    out = []
    # 3*3
    anchors_scaled_group = []
    for i, input in enumerate(darknet_output):
        # [batch , anchor_number , width , height , info]
        out_one,anchors_scaled = decode_box(input, anchors[i], classes_num)
        out.append(out_one)
        anchors_scaled_group.append(anchors_scaled)
        
    return out,anchors_scaled_group


# 假数据
# data = (torch.ones((10, 27, 13, 13)), torch.ones(
#     (10, 27, 26, 26)), torch.ones((10, 27, 52, 52)))
# out = decode(data, 4)
# print(out[0].shape, out[1].shape, out[2].shape)
